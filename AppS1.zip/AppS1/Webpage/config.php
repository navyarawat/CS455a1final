<?php
$host       = "localhost";
$username   = "root";
$password   = "root";
$dbname     = "a1CS4552"; // will use later
$dsn        = "mysql:host=$host;dbname=$dbname"; // will use later
$options    = array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
              );
